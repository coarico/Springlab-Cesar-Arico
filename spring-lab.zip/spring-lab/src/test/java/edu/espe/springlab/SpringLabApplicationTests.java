package edu.espe.springlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
